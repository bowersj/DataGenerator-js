# Faker::Movies::BackToTheFuture

```ruby
Faker::Movies::BackToTheFuture.character #=> "Marty McFly"

Faker::Movies::BackToTheFuture.date #=> "November 5, 1955"

Faker::Movies::BackToTheFuture.quote #=> "Roads? Where we're going, we don't need roads."
```
