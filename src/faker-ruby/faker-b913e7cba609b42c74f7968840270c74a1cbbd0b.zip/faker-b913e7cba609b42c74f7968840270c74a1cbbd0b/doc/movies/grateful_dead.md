# Faker::Movies::GratefulDead

It might be available in the next version.

```ruby
  Faker::Movies::GratefulDead.player #=> "Jerry Garcia"

  Faker::Movies::GratefulDead.song #=> "China Cat Sunflower"
```
