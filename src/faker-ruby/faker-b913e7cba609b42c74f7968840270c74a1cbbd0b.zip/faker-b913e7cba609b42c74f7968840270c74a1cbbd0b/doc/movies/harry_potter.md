# Faker::Movies::HarryPotter

Available since version 1.7.3.

```ruby
Faker::Movies::HarryPotter.character #=> "Harry Potter"

Faker::Movies::HarryPotter.location #=> "Hogwarts"

Faker::Movies::HarryPotter.quote #=> "I solemnly swear that I am up to no good."

Faker::Movies::HarryPotter.book #=> "Harry Potter and the Chamber of Secrets"

Faker::Movies::HarryPotter.house #=> "Gryffindor"

Faker::Movies::HarryPotter.spell #=> "Reparo"
```
