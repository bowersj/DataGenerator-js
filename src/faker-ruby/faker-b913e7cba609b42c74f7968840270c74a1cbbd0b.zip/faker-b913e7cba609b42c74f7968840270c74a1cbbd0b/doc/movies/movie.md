# Faker::Movie

```ruby
 Faker::Movie.quote #=> "Bumble bee tuna"
```
