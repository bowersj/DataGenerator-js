# Faker::Creature::Animal

It might be available in the next version.

```ruby
Faker::Creature::Animal.name #=> "Antelope"
```
