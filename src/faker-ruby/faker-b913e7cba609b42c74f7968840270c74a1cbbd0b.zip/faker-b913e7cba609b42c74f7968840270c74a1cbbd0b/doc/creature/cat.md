# Faker::Creature::Cat

Available since version 1.6.2.

```ruby
# Random cat name
Faker::Creature::Cat.name #=> "Shadow"

# Random cat breed
Faker::Creature::Cat.breed #=> "British Semipi-longhair"

# Random cat registry
Faker::Creature::Cat.registry #=> "American Cat Fanciers Association"
```
