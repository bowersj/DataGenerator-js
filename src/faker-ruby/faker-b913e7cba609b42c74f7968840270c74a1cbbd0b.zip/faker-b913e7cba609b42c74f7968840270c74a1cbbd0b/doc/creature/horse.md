# Faker::Creature::Horse

It might be available in the next version.

```ruby
Faker::Creature::Horse.name #=> "Noir"

Faker::Creature::Horse.breed #=> "Spanish Barb see Barb Horse"
```
