# Faker::Music::Opera

```ruby
Faker::Music::Opera.verdi #=> "Il Trovatore"
Faker::Music::Opera.rossini #=> "Il Barbiere di Siviglia"
Faker::Music::Opera.donizetti #=> "Lucia di Lammermoor"
Faker::Music::Opera.bellini #=> "Norma"
```
