# Faker::Music::RockBand

```ruby
Faker::Music::RockBand.name #=> "Led Zeppelin"
```
