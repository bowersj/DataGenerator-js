# Faker::Music::GratefulDead


```ruby
  Faker::Music::GratefulDead.player #=> "Jerry Garcia"

  Faker::Music::GratefulDead.song #=> "Cassidy"
```
