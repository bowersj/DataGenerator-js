# Faker::Music::Phish

```ruby
Faker::Music::Phish.song #=> "Tweezer"
```
