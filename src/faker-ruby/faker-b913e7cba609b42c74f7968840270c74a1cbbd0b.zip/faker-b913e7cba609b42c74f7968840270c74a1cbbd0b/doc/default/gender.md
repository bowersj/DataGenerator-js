# Faker::Gender

Available since version 1.9.0.

```ruby
Faker::Gender.type #=> "Non-binary"

Faker::Gender.binary_type #=> "Female"
```
