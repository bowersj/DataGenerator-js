# Faker::MichaelScott

Available since version 1.9.0.

```ruby
Faker::MichaelScott.quote #=> "I am Beyoncé, always."
```
