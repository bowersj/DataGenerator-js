# Faker::NationalHealthService

It might be available in the next version

```ruby
Faker::NationalHealthService.british_number #=> "403 958 5577"

Faker::NationalHealthService.check_digit(400_012_114) #=> 6
```
