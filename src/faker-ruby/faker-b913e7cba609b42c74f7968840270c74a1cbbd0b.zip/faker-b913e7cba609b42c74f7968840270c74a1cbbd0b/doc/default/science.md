# Faker::Science

```ruby
Faker::Science.element #=> "Carbon"

Faker::Science.element_symbol #=> "Pb"

Faker::Science.scientist #=> "Isaac Newton"
```
