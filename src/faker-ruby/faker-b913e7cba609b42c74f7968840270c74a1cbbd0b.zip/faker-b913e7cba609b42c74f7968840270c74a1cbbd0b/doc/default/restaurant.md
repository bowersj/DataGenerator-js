# Faker::Restaurant

It might be available in the next version.

```ruby
Faker::Restaurant.name          #=> "Curry King"

Faker::Restaurant.type          #=> "Comfort Food"

Faker::Restaurant.description   #=> "We are committed to using the finest ingredients in our recipes. No food leaves our kitchen that we ourselves would not eat."

Faker::Restaurant.review        #=> "Brand new. Great design. Odd to hear pop music in a Mexican establishment. Music is a bit loud. It should be background."
```
