# Faker::DcComics

It might be available in the next version.

A fun collection of hundreds of your favorite DC Comics Heroes, Heroines, Villains, Alter Egos and Side Characters. Have fun!

```ruby
Faker::DcComics.hero #=> "Batman"

Faker::DcComics.heroine #=> "Supergirl"

Faker::DcComics.villain #=> "The Joker"

Faker::DcComics.name #=> "Clark Kent"

Faker::DcComics.title #=> "Teen Titans: The Judas Contract
```
