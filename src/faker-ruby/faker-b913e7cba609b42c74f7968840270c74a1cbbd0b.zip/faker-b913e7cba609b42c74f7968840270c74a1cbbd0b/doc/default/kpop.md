# Faker::Kpop

```ruby

Faker::Kpop.i_groups # 1990's og groups =>  "Seo Taiji and Boys"

Faker::Kpop.ii_groups # 2000's groups =>  "Girls' Generation"

Faker::Kpop.iii_groups # 2010's groups =>  "Trouble Maker"

Faker::Kpop.girl_groups # girl groups =>  "2NE1"

Faker::Kpop.boy_bands # boy bands =>  "Exo"

Faker::Kpop.solo # solo artists => "T.O.P"

```
