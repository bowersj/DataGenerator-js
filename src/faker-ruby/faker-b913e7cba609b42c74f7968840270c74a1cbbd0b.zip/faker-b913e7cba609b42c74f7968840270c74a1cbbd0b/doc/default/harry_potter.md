# Faker::HarryPotter

Available since version 1.7.3.

```ruby
Faker::HarryPotter.character #=> "Harry Potter"

Faker::HarryPotter.location #=> "Hogwarts"

Faker::HarryPotter.quote #=> "I solemnly swear that I am up to no good."

Faker::HarryPotter.book #=> "Harry Potter and the Chamber of Secrets"

Faker::HarryPotter.house #=> "Gryffindor"

Faker::HarryPotter.spell #=> "Reparo"
```
