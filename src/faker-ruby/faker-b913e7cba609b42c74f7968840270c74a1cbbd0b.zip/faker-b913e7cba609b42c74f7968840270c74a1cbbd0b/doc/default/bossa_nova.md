# Faker::BossaNova

```ruby
Faker::BossaNova.artist #=> "Tom Jobin"

Faker::BossaNova.song #=> "Chega de Saudade"
```
