# Faker::Boolean

Available since version 1.6.2.

```ruby
# Optional parameter: true_ratio=0.5
Faker::Boolean.boolean #=> true

Faker::Boolean.boolean(0.2) #=> false
```
