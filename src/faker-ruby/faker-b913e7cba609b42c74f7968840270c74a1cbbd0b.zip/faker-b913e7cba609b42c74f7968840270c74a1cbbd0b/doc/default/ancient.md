# Faker::Ancient

Available since version 1.7.0.

```ruby
Faker::Ancient.god #=> "Zeus"

Faker::Ancient.primordial #=> "Gaia"

Faker::Ancient.titan #=> "Atlas"

Faker::Ancient.hero #=> "Achilles"
```
