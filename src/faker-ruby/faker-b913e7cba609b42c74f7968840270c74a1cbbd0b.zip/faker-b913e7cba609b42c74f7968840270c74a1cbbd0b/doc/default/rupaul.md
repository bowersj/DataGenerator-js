# Faker::RuPaul

Available since version 1.8.0.

```ruby
Faker::RuPaul.quote #=> "That's Funny, Tell Another One"
Faker::RuPaul.queen #=> "Latrice Royale"
```
