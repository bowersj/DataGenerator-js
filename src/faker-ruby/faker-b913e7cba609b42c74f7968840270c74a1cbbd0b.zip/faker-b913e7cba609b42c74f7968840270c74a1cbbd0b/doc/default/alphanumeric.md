# Faker::Alphanumeric

It might be available in the next version.

```ruby
Faker::Alphanumeric.alpha 10 #=> "zlvubkrwga"

Faker::Alphanumeric.alphanumeric 10 #=> "3yfq2phxtb"
```
