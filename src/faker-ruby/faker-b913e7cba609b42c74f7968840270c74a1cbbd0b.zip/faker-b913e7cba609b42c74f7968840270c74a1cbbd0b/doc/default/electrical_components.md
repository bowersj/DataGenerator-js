# Faker::ElectricalComponents

Available since version 1.9.0.

```ruby
Faker::ElectricalComponents.active #=> "Transistor"

Faker::ElectricalComponents.passive #=> "Resistor"

Faker::ElectricalComponents.electromechanical #=> "Toggle Switch"
```
