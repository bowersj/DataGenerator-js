# Faker::Marketing

```ruby
Faker::Marketing.buzzwords #=> "rubber meets the road", "sprint to the finish line"
```
