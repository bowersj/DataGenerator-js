# Faker::Military

It might be available in the next version.

```ruby
Faker::Military.army_rank #=> "Staff Sergeant"

Faker::Military.marines_rank #=> "Gunnery Sergeant"

Faker::Military.navy_rank #=> "Seaman"

Faker::Military.air_force_rank #=> "Captain"

Faker::Military.dod_paygrade #=> "E-6"
```
