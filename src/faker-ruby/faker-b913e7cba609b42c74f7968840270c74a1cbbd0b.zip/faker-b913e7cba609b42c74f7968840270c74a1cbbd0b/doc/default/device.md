# Faker::Device

Available since version 1.9.0.

```ruby
Faker::Device.build_number #=> "5"

Faker::Device.manufacturer #=> "Apple"

Faker::Device.model_name #=> "iPhone 4"

Faker::Device.platform #=> "webOS"    

Faker::Device.serial #=> "ejfjnRNInxh0363JC2WM"    

Faker::Device.version #=> "4"
```
