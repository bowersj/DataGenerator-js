# Faker::JapaneseMedia::DragonBall

Available since version 1.8.0.

```ruby
Faker::JapaneseMedia::DragonBall.character #=> "Goku"
```
