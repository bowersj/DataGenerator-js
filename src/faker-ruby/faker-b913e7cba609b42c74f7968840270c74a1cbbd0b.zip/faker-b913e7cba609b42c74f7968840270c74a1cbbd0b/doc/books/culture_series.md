# Faker::Books::CultureSeries

```ruby
Faker::Books::CultureSeries.book #=> "The Player of Games"

Faker::Books::CultureSeries.culture_ship #=> "Fate Amenable To Change"

Faker::Books::CultureSeries.culture_ship_class #=> "General Systems Vehicle"

Faker::Books::CultureSeries.culture_ship_class_abv #=> "GSV"

Faker::Books::CultureSeries.civ #=> "Culture"

Faker::Books::CultureSeries.planet #=> "Xinth"
```
