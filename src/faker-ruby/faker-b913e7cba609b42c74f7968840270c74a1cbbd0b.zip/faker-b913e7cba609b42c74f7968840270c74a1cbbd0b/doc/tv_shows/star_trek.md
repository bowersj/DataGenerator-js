# Faker::TvShows::StarTrek

Available since version 1.8.0.

```ruby
Faker::TvShows::StarTrek.character #=> "Spock"

Faker::TvShows::StarTrek.location #=> "Cardassia"

Faker::TvShows::StarTrek.specie #=> "Ferengi"

Faker::TvShows::StarTrek.villain #=> "Khan Noonien Singh"

```
