# Faker::TvShows::RickAndMorty

Available since version 1.8.0.

```ruby
Faker::TvShows::RickAndMorty.character #=> "Rick Sanchez"

Faker::TvShows::RickAndMorty.location #=> "Dimension C-132"

Faker::TvShows::RickAndMorty.quote #=> "Ohh yea, you gotta get schwifty."
```