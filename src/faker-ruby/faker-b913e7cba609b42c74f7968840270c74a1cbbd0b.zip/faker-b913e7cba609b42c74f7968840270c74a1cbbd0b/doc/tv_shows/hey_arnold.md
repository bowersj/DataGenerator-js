# Faker::TvShows::HeyArnold

Available since version 1.8.0.

```ruby

Faker::TvShows::HeyArnold.character #=> "Arnold"

Faker::TvShows::HeyArnold.location #=> "Big Bob's Beeper Emporium"

Faker::TvShows::HeyArnold.quote #=> "Stoop Kid's afraid to leave his stoop!"

```
