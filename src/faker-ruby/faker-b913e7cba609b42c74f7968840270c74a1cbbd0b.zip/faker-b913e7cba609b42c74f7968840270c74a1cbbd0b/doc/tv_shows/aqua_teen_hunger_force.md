# Faker::TvShows::AquaTeenHungerForce

```ruby
Faker::TvShows::AquaTeenHungerForce.character #=> "Master Shake"
```
