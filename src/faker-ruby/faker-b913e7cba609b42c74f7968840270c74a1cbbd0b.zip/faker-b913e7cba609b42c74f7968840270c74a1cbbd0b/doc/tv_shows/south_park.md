# Faker::TvShows::SouthPark

It might be available in the next version.

```ruby
Faker::TvShows::SouthPark.character #=> "Mr. Garrison"

Faker::TvShows::SouthPark.quote #=> "I'm just getting a little cancer Stan"
```
