# Faker::TvShows::TheFreshPrinceOfBelAir

```ruby
Faker::TvShows::TheFreshPrinceOfBelAir.character #=> "Will Smith"

Faker::TvShows::TheFreshPrinceOfBelAir.celebrity #=> "Quincy Jones"

Faker::TvShows::TheFreshPrinceOfBelAir.quote #=> "Girl, you look so good, I would marry your brother just to get in your family."
```
