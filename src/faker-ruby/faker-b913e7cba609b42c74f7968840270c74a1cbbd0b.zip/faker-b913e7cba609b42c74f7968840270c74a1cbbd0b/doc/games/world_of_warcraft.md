# Faker::Games::WorldOfWarcraft

```ruby
# Generate random character from the World of Warcraft
Faker::Games::WorldOfWarcraft.hero #=> "Uther the Lightbringer"

# Generate random quote from the World of Warcraft
Faker::Games::WorldOfWarcraft.quote #=> "These are dark times indeed."
```
