# Faker::Games::HeroesOfTheStorm

It might be available in the next version.

```ruby
Faker::Games::HeroesOfTheStorm.battleground #=> "Towers of Doom"

Faker::Games::HeroesOfTheStorm.class #=> "Support"

Faker::Games::HeroesOfTheStorm.hero #=> "Illidan"

Faker::Games::HeroesOfTheStorm.quote #=> "MEAT!!!"
```
