# Faker::Games::House

It might be available in the next version.

 ```ruby
Faker::Games::Heroes.name #=> "Christian"

Faker::Games::Heroes.specialty #=> "Ballista"

Faker::Games::Heroes.klass #=> "Knight"
```
