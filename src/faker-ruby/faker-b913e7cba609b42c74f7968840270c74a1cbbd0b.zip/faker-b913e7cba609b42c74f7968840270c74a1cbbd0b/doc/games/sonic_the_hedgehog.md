# Faker::Games::SonicTheHedgehog

```ruby
# Any character from the games
Faker::Games::SonicTheHedgehog.character #=> "Sonic the Hedgehog"

# Any zone from the series
Faker::Games::SonicTheHedgehog.zone #=> "The Legend of Zelda Zone"

# Any game from the franchise
Faker::Games::SonicTheHedgehog.game #=> "Waku Waku Sonic Patrol Car"
```
