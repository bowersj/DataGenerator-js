# Faker::Games::Zelda

Available since version 1.7.3.

```ruby
# Random Zelda game
Faker::Games::Zelda.game #=> "Ocarina of Time"

# Random Zelda character
Faker::Games::Zelda.character #=> "Guru-Guru"

# Random Zelda location
Faker::Games::Zelda.location #=> "Tarrey Town"

# Random Zelda item
Faker::Games::Zelda.item #=> "Master Sword"
```
