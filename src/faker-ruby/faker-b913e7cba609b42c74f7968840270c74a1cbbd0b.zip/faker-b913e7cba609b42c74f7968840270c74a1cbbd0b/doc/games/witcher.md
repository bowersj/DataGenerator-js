# Faker::Games::Witcher

```ruby

Faker::Games::Witcher.character # => "Triss Merigold"

Faker::Games::Witcher.witcher # => "Geralt of Rivia"

Faker::Games::Witcher.location # => "Novigrad"

Faker::Games::Witcher.school # => "Wolf"

Faker::Games::Witcher.quote # => "No Lollygagin'!"

Faker::Games::Witcher.monster # => "Katakan"
