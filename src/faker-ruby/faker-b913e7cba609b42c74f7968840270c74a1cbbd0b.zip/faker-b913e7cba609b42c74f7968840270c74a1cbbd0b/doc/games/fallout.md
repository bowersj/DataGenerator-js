# Faker::Games::Fallout

```ruby
Faker::Games::Fallout.character #=> "Dogmeat"

Faker::Games::Fallout.faction #=> "The Institute"

Faker::Games::Fallout.location #=> "Capital Wasteland"

Faker::Games::Fallout.quote #=> "Democracy is non-negotiable"
```
