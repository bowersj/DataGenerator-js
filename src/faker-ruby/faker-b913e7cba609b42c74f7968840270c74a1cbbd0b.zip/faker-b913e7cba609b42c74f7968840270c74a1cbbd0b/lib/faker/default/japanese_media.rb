# frozen_string_literal: true

module Faker
  module JapaneseMedia
  end
end
