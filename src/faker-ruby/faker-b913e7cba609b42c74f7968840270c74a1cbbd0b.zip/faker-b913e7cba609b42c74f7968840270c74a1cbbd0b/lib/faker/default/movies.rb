# frozen_string_literal: true

module Faker
  module Movies
  end
end
